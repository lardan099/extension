const STREAM_URL_VK = 'https://live.vkvideo.ru/grpzdc';
const CHECK_INTERVAL_MINUTES = 5;  // Проверять каждые 5 минут
const NOTIFICATION_ID = 'stream_start';

// Ссылки на платформы
const PLATFORMS = {
  vk: 'https://live.vkvideo.ru/grpzdc/',
  youtube: 'https://www.youtube.com/channel/UC5Zw6Myp8Ngt1LfBv-ot2jw/live',
  kick: 'https://kick.com/grpzdc'
};

// Функция проверки статуса стрима на VK
async function checkStreamStatus() {
  browser.storage.local.get(['defaultPlatform', 'lastNotificationDate'], async (result) => {
    if (!result.defaultPlatform) {
      return;
    }

    try {
      const response = await fetch(STREAM_URL_VK, { mode: 'cors' });
      const html = await response.text();

      const isLive = html.includes('Live') || html.includes('В прямом эфире') || html.includes('live-indicator');

      if (isLive) {
        const today = new Date().toDateString();
        if (result.lastNotificationDate !== today) {
          browser.notifications.create(NOTIFICATION_ID, {
            title: 'Стрим начался!',
            message: `Смотреть на ${result.defaultPlatform.charAt(0).toUpperCase() + result.defaultPlatform.slice(1)}`,
            iconUrl: '/icon.png',
            type: 'basic'
          });

          browser.storage.local.set({ lastNotificationDate: today });
        }
      }
    } catch (error) {
      console.error('Ошибка проверки стрима:', error);
    }
  });
}

// Устанавливаем периодическую проверку
browser.alarms.create('checkStream', { 
  periodInMinutes: CHECK_INTERVAL_MINUTES,
  when: Date.now()
});

// Слушатель для alarm
browser.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'checkStream') {
    checkStreamStatus();
  }
});

// Обработчик клика по уведомлению
browser.notifications.onClicked.addListener((id) => {
  if (id === NOTIFICATION_ID) {
    browser.storage.local.get(['defaultPlatform'], (result) => {
      const url = PLATFORMS[result.defaultPlatform];
      if (url) {
        browser.tabs.create({ url });
      }
    });
  }
});

// Открываем страницу настроек при установке
browser.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    browser.runtime.openOptionsPage();
  }
});

// Слушаем сообщения от options.js
browser.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'platformSaved') {
    checkStreamStatus();
  }
});