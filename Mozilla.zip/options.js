const browserAPI = typeof chrome !== 'undefined' ? chrome : browser;

// Загружаем сохранённую платформу
browserAPI.storage.local.get(['defaultPlatform'], (result) => {
  if (result.defaultPlatform) {
    document.getElementById('platformSelect').value = result.defaultPlatform;
  }
});

// Сохраняем выбор платформы
document.getElementById('saveButton').addEventListener('click', () => {
  const platform = document.getElementById('platformSelect').value;
  if (platform) {
    browserAPI.storage.local.set({ defaultPlatform: platform }, () => {
      const status = document.getElementById('status');
      status.textContent = 'Настройки сохранены!';
      setTimeout(() => { status.textContent = ''; }, 2000);
      // Отправляем сообщение в background.js для немедленной проверки
      browserAPI.runtime.sendMessage({ action: 'platformSaved' });
    });
  } else {
    const status = document.getElementById('status');
    status.textContent = 'Пожалуйста, выберите платформу!';
    setTimeout(() => { status.textContent = ''; }, 2000);
  }
});